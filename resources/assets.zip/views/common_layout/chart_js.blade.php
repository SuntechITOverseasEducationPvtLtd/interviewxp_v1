 <script src='{{url('/')}}/assets/charts/canvas-gauges/gauge.min.js'></script>
<script src='{{url('/')}}/assets/charts/chartist/chartist.min.js'></script>
<link rel='stylesheet' type='text/css' href='{{url('/')}}/assets/charts/chartist/chartist.min.css'/>
<script src='{{url('/')}}/assets/charts/chartjs/Chart.js'></script>
<script type='text/javascript' src='{{url('/')}}/assets/charts/fusioncharts/fusioncharts.js'></script>
<script type='text/javascript' src='{{url('/')}}/assets/charts/fusioncharts/themes/fusioncharts.theme.fint.js'></script>

<script type='text/javascript' src='{{url('/')}}/assets/charts/loader.js'></script>
<script type='text/javascript' src='{{url('/')}}/assets/charts/jsapi'></script>
<script type='text/javascript'>google.charts.load('current', {'packages':['corechart', 'gauge', 'geochart', 'bar', 'line']});</script>

<script src='{{url('/')}}/assets/charts/highcharts/js/highcharts.js'></script>
<script src='{{url('/')}}/assets/charts/highcharts/js/modules/exporting.js'></script>
<script src='{{url('/')}}/assets/charts/highmaps/js/modules/map.js'></script>
<script src='{{url('/')}}/assets/charts/highmaps/js/modules/data.js'></script>
<script src='{{url('/')}}/assets/charts/highmaps/maps/world.js'></script>
<script src='{{url('/')}}/assets/charts/justgage/raphael-2.1.4.min.js'></script>
<script src='{{url('/')}}/assets/charts/justgage/justgage.js'></script>
<link rel='stylesheet' href='{{url('/')}}/assets/charts/morris/morris.css'>
<script type='text/javascript' src='{{url('/')}}/assets/charts/morris/raphael.min.js'></script>
<script type='text/javascript' src='{{url('/')}}/assets/charts/morris/morris.min.js'></script>
<script src='{{url('/')}}/assets/charts/d3/d3.js'></script>
<link rel='stylesheet' href='{{url('/')}}/assets/charts/plottable/plottable.css'>
<script src='{{url('/')}}/assets/charts/plottable/plottable.js'></script>
<script src='{{url('/')}}/assets/charts/progressbar/progressbar.min.js'></script>
{{-- <script src='{{url('/')}}/assets/charts/js/jsapi_compiled_default_module.js'></script> --}}