@extends('front.layout.main')
@section('middle_content')
<div class="banner-change-pw">
         <div class="pattern-change-pw">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="heading-changepw">{{$module_title}}</div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
       <div class="middle-area min-height">
           <div class="container">
               <div class="row">
                   <div class="col-md-6 form-wrapper">
                       <div class="form-group">
                           <label><h1>Coming Soon</h1></label>
                           
                           <!--div class="error">Password is not Valid</div-->
                       </div>
                       
                   </div>
               </div>
           </div>
           
       </div>
    
        

@endsection