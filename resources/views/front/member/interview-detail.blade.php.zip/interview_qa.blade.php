	
	<tr style="background-color: #fff;">
		<td colspan="5"><p style="margin-bottom: -5px" class="show-results">Showing {{($reference_book_details->currentpage()-1)*$reference_book_details->perpage()+1}} to {{($reference_book_details->currentpage()-1) * $reference_book_details->perpage() + $reference_book_details->count()}}
    of  {{$reference_book_details->total()}} results</p>
		<input type="hidden" id="tot_interviewqa_topics-{{$interview_id}}" name="tot_interviewqa_topics" value="{{$reference_book_details->total()+1}}">
																	
		</td>
	</tr>
	
	  
		<tr style="background-color: #f5f5f5;">
		  <td><b>Topic Name</b></td>
		  <td><b>File Size</b></td>
		  <td><b>Date & Time</b></td>
		  <td><b>Status</b></td>
		  <td  style="text-align: center;"><b>Action</b></td>
	   </tr>
	   <tr style="background-color: #d9edf7;display:none"  class="topicSave">
		   <td colspan="5">
		    <div style="clear:both;"></div>
			<!-- topic save -->
			<div class="form-group" style="">
				<div class="col-md-12" style="padding:0px;">
					<span class="col-md-8 addTopicname" style="margin-top: 8px; padding: 0px;"></span>
					<span class="col-md-2" style="margin-top: 8px; padding: 0px 0px 0px 7px; text-align: center;">Pending</span>
					<div class="col-md-2" style="padding:0px">
					<span class="col-md-1 editTopic" style="margin-top: 8px;padding-left: 2px;margin-left: 6px;"><i class="fa fa-pencil"></i></span>
					<span class="col-md-1 deleteTopic" style="margin-top: 8px;padding-left: 2px;margin-left: 7px;"><i class="fa fa-trash-o"></i></span>						
					<span class="col-md-2 showPDFExcelAdd" attrpartscount="0" attrId="{{@$interview_id}}" style="background-color: #17b0a4;border: 1px solid #17b0a4;float: right;color: #fff;padding: 5px;width:92px;"><i class="fa fa fa-plus"></i> Add Part</span>
					</div>
				</div>
			</div>
			
			</td>
	   </tr>
	   <tr id="addbook-row{{@$interview_id}}" style="background-color:#fff; display: none;">
			<td class="" colspan="5">
				<div class="addbook" style="height:22px;">
			   <div class="row">
			   </div>
			   {{ csrf_field() }}
			   
			   <input type="hidden" class="interviewid"  id="unique_id" value="{{@$interview_id}}">
			   <input type="hidden" id="skill_id_reference-{{@$interview_id}}" value="{{@$uploads['skill_id']}}">
			   <input type="hidden" id="experience_level_reference-{{@$interview_id}}" value="{{@$uploads['experience_level']}}">
			   <div style="color:green;" id="reference_success_msg-{{@$interview_id}}">
			</div>																	
			
			<div style="clear:both;"></div>
			<div class="form-group videoPdfIcon" style="border:1px solid #ccc;padding:5px;">
			  <div class="row">
				<div class="col-sm-12 col-md-4 col-lg-4 part-text">New Part</div>
				<div class="col-sm-12 col-md-8 col-lg-8">
					<div class="col-sm-12 col-md-4 col-lg-4 videoIcon"><i class="fa fa-play"  style="font-size:30px; border: 1px solid #ccc;padding: 15px;margin-top:10px;"></i><span style="clear: both;display: block;">Video (MP4)</span></div>
					<div class="col-sm-12 col-md-4 col-lg-4 pdfIcon"><i class="fa fa-file-pdf-o" style="font-size:30px; border: 1px solid #ccc;padding: 15px;margin-top:10px;"></i><span style="clear: both;display: block;margin-left: 20px;">Pdf</span></div>
					<div style="clear:both;"></div>
				</div>
				</div>
			</div>
			<div style="clear:both;"></div>
			<div class="form-group">
			   <div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12">
					<div class="videoclass" style="border: 1px solid #ccc;padding:15px;">
						<!--<input id="reference_book-{{@$interview_id}}"  style="visibility:hidden; height: 0;" name="reference_book" type="file">-->
						 <div class="input-group col-sm-12 col-md-12 col-lg-12">
							<div class="btn btn-primary btn-gry col-sm-6 col-md-6 col-lg-6" style="background-color: #eee;border:none;">
							   <!--<a class="file" onclick="browseReferenceBook({{@$interview_id}})">Choose File
							   </a>-->
							   <input id="reference_book-{{@$interview_id}}" accept="video/mp4" class="reference_bookVideo-{{@$interview_id}} reference_bookVideo" onchange="setFileInfo(this.files)" name="reference_book" type="file">
							</div>
							<input type="hidden" name="durationVideo" id="durationVideo">
							<div class="col-sm-6 col-md-6 col-lg-6">
								
								<div class="btn btn-warning cancelFinalBtn" style="padding: 11px;height: 40px;float:right;margin-top: 0px;background-color: #17b0a4; width:125px;margin-left: 10px;border:none;">Cancel</div>
								<button  type="button" id="update_reference_book" onclick="javascript: return refbookupload({{@$interview_id}});" style="float:right;width:125px;" class="submit-btn ctn bookbtn">Upload</button>
							</div>
							<div class="btn btn-primary btn-file remove" style="border-right: 1px solid rgb(251, 251, 251) ! important; display: none;" id="btn_remove_reference_book-{{@$interview_id}}">
							   <a class="file" onclick="removeReferenceBook({{@$interview_id}})"><i class="fa fa-trash"></i>
							   </a>
							</div>
							<input class="form-control file-caption  kv-fileinput-caption" id="reference_book_name-{{@$interview_id}}" disabled="disabled" type="text" style="height: 38px;">
							<h5 class="upload">Support Formats: MP4, Max File 300 MB</h5>
							<h5 class="upload">Tip: video is InterviewXp's preferred delivery type wide screen 16:9 ratio is preferred. Please note that the average video length is within 5-10 minutes. Content should be with high resolution video 720p (1280x720)</h5>
							<div id="error_msg-{{@$interview_id}}" class="error"></div>
							<div id="create_error_attachment-{{@$interview_id}}" class="error" style="left:0;"></div>
						 </div>
					</div>
					<div class="pdfclass" style="border: 1px solid #ccc;padding:15px;">
						<!--<input id="reference_book-{{@$interview_id}}"  style="visibility:hidden; height: 0;" name="reference_book" type="file">-->
						 <div class="input-group  col-sm-12 col-md-12 col-lg-12">
							
							<div class="col-sm-6 col-md-6 col-lg-6 btn btn-primary  btn-gry" style="background-color: #eee;border:none;">
							   <!--<a class="file" onclick="browseReferenceBook({{@$interview_id}})">Choose File
							   </a>-->
							   <input id="reference_book-{{@$interview_id}}" class="reference_bookPdf-{{@$interview_id}} reference_bookPdf" accept="application/pdf" name="reference_book" type="file">
							</div>
							<div class="col-sm-6 col-md-6 col-lg-6">
								<button  type="button" id="update_reference_book" onclick="javascript: return refbookupload({{@$interview_id}});" style="margin-right:10px;width:125px; float:right"  class="member-profile-btn ctn bookbtn">Upload</button>
								<div class="cancelFinalBtn" style="padding: 11px;height: 40px;margin-top: 0px;color: #17b0a4; width:80px;margin-right: 10px;border:none; float:right">Cancel</div>								
							</div>
							<div class="btn btn-primary btn-file remove"  style="border-right: 1px solid rgb(251, 251, 251) ! important; display: none;" id="btn_remove_reference_book-{{@$interview_id}}">
							   <a class="file" onclick="removeReferenceBook({{@$interview_id}})"><i class="fa fa-trash"></i>
							   </a>
							</div>
							<input class="form-control file-caption  kv-fileinput-caption" id="reference_book_name-{{@$interview_id}}" disabled="disabled" type="text" style="height: 38px;">
							<h5 class="upload">Support Formats: PDF, Max File 2 MB</h5>
							<div id="error_msg-{{@$interview_id}}" class="error"></div>
							<div id="create_error_attachment-{{@interview_id}}" class="error" style="left:0;"></div>
						 </div>
					</div>
				</div>
				
			   </div>
				  <div class="clearfix"></div>
			   </div>

			</div>
			</td>
	   </tr>

	   <?php
	   //$results = DB::select( DB::raw("SELECT * FROM multi_reference_book WHERE interview_id = '".$interview_id."' group by topic_name ORDER BY `multi_reference_book`.`id` DESC") );
		
		foreach ($reference_book_details as $key=>$user) {
			
			$delete="/member/delete_reference_book_all/".base64_encode($user->topic_name);
			$string = ucwords(strtolower(mb_strimwidth($user->topic_name, 0, 95, '...')));
			$results1 = DB::select( DB::raw("SELECT * FROM multi_reference_book WHERE interview_id = '".$user->interview_id."' AND topic_name = '".$user->topic_name."' ORDER BY `multi_reference_book`.`id` DESC") );			
			?>
			<tr style="background-color: #d9edf7">
				<td colspan="5" title="{{$string}}">{{($reference_book_details->currentpage()-1)*$reference_book_details->perpage()+1+$key}} . {{$string}} 
				<span style="float:right"><span style="margin-left:10px;color:rgba(85, 85, 85, 0.82)"><i class="fa fa-pencil"></i></span>
				@if($user->approve_status == 0)
				<a style="margin-left:10px;color:rgba(85, 85, 85, 0.82)" href="{{$delete}}" onclick="return confirm('Are you sure to Delete this record?')"><i class="fa fa-trash-o"></i></a>
				@else
				<span style="margin-left: 10px;"><i class="fa fa-trash-o"></i></span>	
				@endif
				<span class="showPDFExcelAdd" attrPartsCount="{{@count($results1)}}" attrId="{{$user->interview_id}}" skillId="" txtattr="{{$user->topic_name}}" style="background-color: #17b0a4;border: 1px solid #17b0a4;color: #fff;padding: 5px;margin-left:10px;"><i class="fa fa fa-plus"></i> Add Part</span></span></td>
			 </tr>
				<?php
					   foreach ($results1 as $key1=>$user1) {
							
							 if($user1->file_extension =='Pdf'){
								 $icon='<i class="fa fa-file-pdf-o"></i>';
							 }else if($user1->file_extension =='Video'){
								 $icon='<i class="fa fa-play"></i>';
							 }else{
								 $icon="";
							 }
							 $viewicon=url('/')."/images/viewicon.png";
								 
							 if($user1->approve_status==1){
								 $status="Approved";
								 $freeView="";
								 $url="/member/delete_reference_book/".base64_encode($user->id);
								 $dow="/uploads/refrence_book/".$user->mul_reference_book;
								 $action='<a style="color:rgba(85, 85, 85, 0.82)" href="'.$dow.'" target="_New"><img src="'.$viewicon.'" alt="Interviewxp" title="View"/></a><a style="margin-left:10px;" href="'.$dow.'"  title="Download" download="" class="download-i"><i style="color: rgba(85, 85, 85, 0.82) !important;" class="fa fa-download" aria-hidden="true"></i></a><a style="margin-left:10px;color:rgba(85, 85, 85, 0.82)" class="editInterview"><i class="fa fa-pencil"  title="Edit" aria-hidden="true"></i></a> <a style="margin-left:10px;color:rgba(85, 85, 85, 0.82)"  title="Delete" class="delete-i"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
							 }
								 
							 else{
								 $status="Pending";
								 $freeView=url('/member/freePreview/').'/'.base64_encode($user1->id);
								 $url="/member/delete_reference_book/".base64_encode($user->id);
								 $dow="/uploads/refrence_book/".$user->mul_reference_book;
								 $action='<a style="color:red" href="'.$dow.'" target="_New"><img src="'.$viewicon.'" alt="Interviewxp" title="View"/></a><a style="margin-left:10px;" href="'.$dow.'"  title="Download" download="" class="download-i"><i style="color: red !important;" class="fa fa-download" aria-hidden="true"></i></a><a style="margin-left:10px;"  title="Edit" data-toggle="modal" href="#ref-book-'.$user->id.'"><i class="fa fa-pencil" aria-hidden="true"></i></a> <a style="margin-left:10px;" href="'.$url.'" onclick="return confirm("Are you sure to Delete this record?")"  title="Delete" class="delete-i"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
							 }
							 
							 
						?>
						<tr>
							<td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $icon ?> &nbsp;&nbsp; Part {{$key1+1}} &nbsp;&nbsp; {{$user1->pageCount}} </td><td>{{$user1->fileSize}} M.B</td>
							<td>{{date('j M, Y, g:i A T',strtotime($user1->created_at))}} 
							<?php 
							if($user1->freePreview ==''&& $status=='Pending'){
							?>
							<a style="margin-left:10px;" href="{{$freeView}}" onclick="return confirm('Are you sure you want make it free?')"> <i class="fa fa-eye-slash" aria-hidden="true" title="Make a free preview" style="color: #17b0a4 !important;"></i></a>
							<?php 
							}else{
								?>
								&nbsp;&nbsp;&nbsp;<i class="fa fa-eye" aria-hidden="true" title="Free Preview" style="color: #17b0a4 !important;"></i>
								<?php
							}
							?>
							</td>
							<td><?php echo $status;?></td>
							<td><?php echo $action;?>
									@if($user1->admin_comments) 
									&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-comments" title="{{$user1->admin_comments}}" style="color: green" ></i>
									@endif
							</td>
						</tr>
						<div class="modal fade popup-cls" id="ref-book-{{@$user->id}}" role="dialog">
						  <div class="modal-dialog">
							 <div class="modal-content">
								<div class="modal-header">
								   <button type="button" class="close" data-dismiss="modal"><img src="{{url('/')}}/images/close-img.png" alt="Interviewxp"/></button>
								   <h4 class="modal-title">Reference Book</h4>
								</div>
								<div class="modal-body">
								   <div class="row">
								   </div>
								   {{ csrf_field() }}
								 <meta name="csrf_token" content="{{ csrf_token() }}" />
								   <div style="color:green;" id='reference_success_msg-{{@$user1->id}}'>
								</div>
								<div class="form-group">
											   <div class="row">
												  <div class="col-sm-12 col-md-4 col-lg-4"><label>Topic Name<span class="error" style="color:red;">*</span></label> 
												  </div>
												  <div class="col-sm-12 col-md-8 col-lg-8">
													 <input class="input-box-signup" type="text" id="updatetopic_name-reference-{{@$user1->id}}" name="updatetopic_name" value="{{@$user->topic_name}}">
													 <div id="updatereference_error_topic-{{@$user1->id}}" class="error"></div>
													 <div id="updatelen_reference_error_topic-{{@$user1->id}}" class="error"></div>
												  </div>
											   </div>
											</div>
								<div class="form-group">
								  <div class="row">
												  <div class="col-sm-12 col-md-4 col-lg-4">
													  <label>Uploads <span class="error" style="color:red;">*</span></label></div>
									<div class="col-sm-12 col-md-8 col-lg-8">
									 <input id="updatereference_book-{{@$user1->id}}"  style="visibility:hidden; height: 0;" name="updatereference_book" type="file">
										 <div class="input-group ">
											<div class="btn btn-primary btn-file btn-gry">
											   <a class="file" onclick="updatebrowseReferenceBook({{@$user1->id}})">Choose File
											   </a>
											</div>
											<div class="btn btn-primary btn-file remove" style="border-right: 1px solid rgb(251, 251, 251) ! important; display: none;" id="updatebtn_remove_reference_book-{{@$user1->id}}">
											   <a class="file" onclick="updateremoveReferenceBook({{@$user1->id}})"><i class="fa fa-trash"></i>
											   </a>
											</div>
											<input class="form-control file-caption  kv-fileinput-caption" id="updatereference_book_name-{{@$user1->id}}" disabled="disabled" type="text" style="height: 38px;">

										   
											
											<h5 class="upload">Support Formats: PDF, Max File 500 KB</h5>
											<div id="error_msg-{{@$user1->id}}" class="error"></div>
								 <div id="updatecreate_error_attachment-{{@$user1->id}}" class="error" style="left:0;"></div>
										 </div>
									  </div>
									  <div class="clearfix"></div>
								   </div>

								</div>
								
								<!--end-->
							 </div>
							 <div class="modal-footer">
								<button  type="button" id="update_reference_book" onclick="javascript: return updaterefbookupload({{@$user1->id}});" class="submit-btn ctn">Upload</button>

							 </div>
						  </div>
						<?php
						}
						?>
			<?php
			
		}
		
	   ?>	
	   <tr>
		  <td colspan="5" style="background-color:#fff">
			  <div class="prod-pagination">
				{{ $reference_book_details->appends(['interview_id'=>$interview_id])->render() }}
			  </div>
		  </td>
		</tr>
		
		