@extends('front.layout.main')
@section('middle_content')
<div id="after-login-header" class="after-login"></div>
<div class="banner-member">
   <div class="pattern-member">
   </div>
</div>
<div class="container">
   <div class="row">
      <div class="col-lg-12">
         <div class="middle-section min-height">
            <div class="user-dashbord">
               <div class="row">
                  <div class="col-sm-12 col-md-12 col-lg-12">
                     <div class="middle part">
                        <div class="row">
                           <div class="col-xs-8">
                              <h2 class="my-profile">{{$module_title}}</h2>
                           </div>
                           <div class="col-xs-4">
                              <div class="icon-w"> 
                                 <a href="{{url('/member/purchase_history')}}" class="green-back m-r-0">Back</i></a>
                              </div>
                           </div>
                        </div>
                        <div class="outer-box r-details">
                           <div class="row">
                              <div class="col-sm-12">
                                 <h5>{{ucfirst($arr_transaction['skill_name'])}} Real Time Interview Questions & Answers ( {{$arr_transaction['experience_level']}} Year Exp )</h5>
                                 <div class="form-group">
                                    <label class="h-text">Experience Level :</label>
                                    <label>{{$arr_transaction['experience_level'] or 'NA'}} Years</label>
                                 </div>
                                 <div class="form-group">
                                    <label class="h-text">Purchased date  : </label>
                                    <label>{{date('d M Y', strtotime($arr_transaction['created_at']))}}</label>
                                 </div>
                                 <div class="form-group">
                                    <label class="h-text">Validity Date  : </label>
                                    <label>{{date('d M Y', strtotime($arr_transaction['end_date']))}}</label>
                                 </div>
                                 <div class="form-group">
                                    <label class="h-text">Amount  : </label>
                                    <label>Rs.{{ $grand_total or 'NA' }}</label>
                                 </div>

                                 @if(isset($arr_transaction['member_interview_info']) && sizeof($arr_transaction['member_interview_info'])>0)
                                 @if($arr_transaction['reference_book'] == 'Yes')

                                 @if(isset($arr_transaction['multi_ref_book']) && sizeof($arr_transaction['multi_ref_book'])>0)
                                    <label class="h-text">Reference Book :</label> 
                               <div class="table-search-pati section1-tab">    
                                 <div class="table-responsive">
                                    <table class="table">
                                       
                                       <thead>
                                          <tr class="top-strip-ta ble">
                                             <td>S.No.</td>
                                             <td style="width: 70%;">Topic Name</td>
                                          </tr>
                                       </thead>
                                        <tbody>
                                       <?php $i = 1; ?>
                                       @foreach($arr_transaction['multi_ref_book'] as $ref_book)
                                       @if($ref_book['updated_at']<$arr_transaction['created_at'])
                                          <tr>
                                             <td>{{$i++}}</td>
                                             <td>{{$ref_book['topic_name']}}</td>
                                          </tr>
                                       @endif   
                                       @endforeach
                                       
                                       </tbody>
                                    </table>
                                 </div>
                               </div> 
                                
                                 @endif

                                 @endif 
                                 @endif

                                 @if(isset($arr_transaction['purchase_history'][0]['interview_attachment']) && sizeof($arr_transaction['purchase_history'][0]['interview_attachment']>0))
                                 @if($interview_count_arr!=0)
                                 <label class="h-text">Interviews by Companies :</label> 
                               <div class="table-search-pati section1-tab">    
                                 <div class="table-responsive">
                                    <table class="table">
                                       
                                       <thead>
                                          <tr class="top-strip-ta ble">
                                             <td>S.No.</td>
                                             <td style="width: 70%;">Company Name</td>
                                          </tr>
                                       </thead>
                                        <tbody>
                                       <?php $i = 1; ?>
                                       @foreach($arr_transaction['purchase_history'] as $company)
                                     
                                          <tr>
                                             <td>{{$i++}}</td>
                                             <td>{{$company['interview_attachment'][0]['company_name']}}</td>
                                          </tr>
                                       
                                       @endforeach
                                       
                                       </tbody>
                                    </table>
                                 </div>
                               </div>  

                                 @endif
                                 @endif

                                 @if($arr_transaction['purchase_history'][0]['ticket_name']!="")   
                                  <div class="form-group">
                                    <label class="h-text width-a">Real Time Work Experience (Tickets, Tasks, Issues) :</label>   
                                    <label>{{$arr_transaction['purchase_history'][0]['ticket_name']}} Rwe Tickets </label>
                                  </div> 
                                <div class="table-search-pati section1-tab">    
                                 <div class="table-responsive">
                                    <table class="table">
                                      
                                       <thead>
                                          <tr class="top-strip-ta ble">
                                             <td>S.No.</td>
                                             <td style="width: 70%;">Ticket Name</td>
                                             
                                          </tr>
                                       </thead>
                                        <tbody>
                                       @if(isset($arr_transaction['ticket_details']) && sizeof($arr_transaction['ticket_details'])>0)
                                       <?php $i = 1; ?>
                                       @foreach($arr_transaction['ticket_details'] as $ticket)
                                       
                                          <tr>
                                             <td>{{$i++}}</td>
                                             <td>{{$ticket['rwe_details'][0]['issue_title']}}</td>
                                          </tr>
                                       
                                       @endforeach
                                       @endif
                                       </tbody>
                                    </table>
                                 </div>
                               </div>  
                                 @endif  
                              </div>
                           </div>
                        </div>
                        <!-- <div class="sample-img2"><img src="images/sample-img3.jpg" class="img-responsive" alt="Interviewxp"/></div> -->
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>

<script type="text/javascript">
   $('.main-content > .arrow').click(function(){
     $(this).parent().next('.sub-content').slideToggle();
     $(this).find('.arrow i').toggleClass('fa-chevron-down fa-chevron-up')
   });
</script>  
<script>
$("tr:even").css("background-color", "#eeeeee"); 
$("tr:odd").css("background-color", "#fff");     
</script>         
<!--footer section-->
@endsection

