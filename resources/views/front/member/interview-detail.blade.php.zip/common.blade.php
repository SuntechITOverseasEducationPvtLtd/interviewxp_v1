@extends('front.layout.main')
@section('middle_content')
<div id="member-header" class="after-login"></div>
<div class="banner-member">
   <div class="pattern-member">
   </div>
</div>
<div class="container-fluid fix-left-bar">
   <div class="row">
      @include('front.member.member_sidebar')  
      <?php
        $reviewStatusArray = [1=>"I hate it", 2=>"I don't like it", 3=>"Its Okay", 4=>"I like it", 5=>"I love it"];
     ?>
      <div class="col-sm-9 col-md-9 col-lg-10 middle-content">
         <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
            <h2 class="my-profile m-history">My Bookings</h2>
               <div class="outer-box history-page">
                  <!--                  <h4>Interviews</h4>-->
                  <!-- tabbing section -->
                  <div class="table-responsive">
                     <table class="table">
                        <thead>
                           <tr class="t-head">
                              <td>S.No</td>
                              <td>Description</td>
                              <td>Experience Level</td>
                              <td>&nbsp;</td>
                           </tr>
                        </thead>
                        @if(isset($arr_interview) && sizeof($arr_interview)>0)
                        @foreach($arr_interview as $key => $uploads)
                        <thead class="box  hideRow hideRow{{$key+1}}">
                           <tr class="top hideAll" id="{{$key+1}}">
							    <?php
									$interview_skill_name = '';
									if(isset($uploads['skill_name']) && isset($uploads['experience_level'])  && $uploads['experience_level'] != 'NA')
									{
										$interview_skill_name = $uploads['skill_name'].' Real Time Interview Questions &amp; Answers';
									}
									else if(($uploads['skill_name']) && isset($uploads['experience_level'])){									
										$interview_skill_name = $uploads['skill_name'].' Interview Questions &amp; Answers';
									}
							    ?>	
                              <td>{{$key+1}}</td>
                              <td>
                                 {{$interview_skill_name}}   
                              </td>
                              <td>
                                 {{isset($uploads['experience_level']) && $uploads['experience_level'] != 'NA'?$uploads['experience_level'].' Year':'NA'}}
                              </td>
                              <td><img src="{{url('/')}}/images/plus_faq.png" /></td>
                           </tr>
                           <tr class="bottom" style="{!! (isset($interviewId)) ? '': 'display:none;' !!}">
                              <td colspan="4">
                                 <div class="multi-tabbing">
								    <div class="panel with-nav-tabs panel-default">
											<div class="tab-content">
											   <div class="table-search-pati section1-tab add-skiils-table middle-bottom">
												  <div class="table-responsive">
													 <table class="table">
														<tbody>
														  <tr class="top-strip-table">
															<td>S.No</td>
															<td>Date Purchased</td>
															<td>Name</td>
															<td>PH.No.</td>
															<td>Email Id</td>
															<td>Ratings</td>
															<td>Reviews</td>
															<td>Status</td>
														</tr>
														<?php
														//echo "SELECT * FROM transaction a, purchase_history b, users c where a.member_user_id='".$uploads['user_id']."' AND a.skill_id='".$uploads['skill_id']."' AND a.order_id=b.order_id AND a.ref_interview_id=b.interview_id AND b.TextResumeType=1 AND a.user_id=c.id";
														 // $results = DB::select( DB::raw("SELECT * FROM transaction a, purchase_history b, users c where a.member_user_id='".$uploads['user_id']."' AND a.skill_id='".$uploads['skill_id']."' AND a.order_id=b.order_id AND a.ref_interview_id=b.interview_id AND b.TextResumeType=1 AND a.user_id=c.id") );
														 
                                           $reviewInfoObj = DB::table('review_rating')
                                                               ->join('transaction', 'transaction.ticket_unique_id', '=', 'review_rating.unique_id')
                                                               ->join('users', 'users.id', '=', 'review_rating.user_id')
                                                               ->where('transaction.member_user_id', $uploads['user_id'])
                                                               ->where('review_rating.interview_id', $uploads['id'])
                                                               ->where('transaction.skill_id', $uploads['skill_id'])
                                                               ->where(['ReviewType'=>'Interview Coaching'])
                                                               ->where(function ($query) {
                                                                   $query->where('approve_status', '=', 'member')
                                                                         ->orWhere('approve_status', '=', 'user');
                                                                     })
                                                               ->get();                                                              

                                           foreach ($reviewInfoObj as $key=>$reviewInfo) {
														 /*$reviewInfo = DB::table('review_rating')
																		->where('user_id', $user->user_id)
																		->where('member_user_id', $uploads['user_id'])
																		->where('interview_id', $user->interview_id)
																		->where('ReviewType', 'Interview Coaching')
																		->first();*/
														if(isset($reviewInfo)){
															$star=$reviewInfo->review_star;
															$msg=$reviewInfo->review_message;
															if($star <=2)
																$staus="Not Satisfied";
															else
																$staus="Completed";
														}else{
															$star="-";
															$msg="";
															$staus="Pending";
														}
                                          $emptyStars = url('/')."/images/blank_star.png";           
                                          $stars = url('/')."/images/star.png";           

														?>
														<tr>
															<td>{{$key+1}}</td>
															<td>{{$reviewInfo->created_at}}</td>
															<td>{{$reviewInfo->first_name}} {{$reviewInfo->last_name}}</td>
															<td>{{$reviewInfo->mobile_no}}</td>
															<td>{{$reviewInfo->email}}</td>
															<td><?php if($star) { for($i=1; $i<=5; $i++) { if($i <= $star) { echo '<img src="'.$stars.'" title="'.$reviewStatusArray[$star].'"/>'; } else { echo '<img src="'.$emptyStars.'" title="'.$reviewStatusArray[$star].'"/>'; } }  } else { for($i=1; $i<=5; $i++) { echo '<img src="'.$emptyStars.'"/>'; } } ?></td>
															<td title="{{$msg}}"><i class='fa fa-eye' aria-hidden='true'></i></td>
															<td>{{$staus}}</td>
														</tr>
														<?php
														}
														?>
														</tbody>
													 </table>
														<!--end-->
													 </div>
												  </div>
											</div>
									</div>
                                </div>
                </div>
               
         </td>
         </tr>
         </thead>
         @endforeach
         @else
         <tr class="strips">
         <td style="color:red;">
         No Records found...
         </td>
         </tr>
         @endif    
         </tr>
         </table>
      </div>
      <!-- end -->
   </div>
		</div>
</div>
   </div>
</div>
<script type="text/javascript">
   
      $('.top').on('click', function() {
     
         $parent_box = $(this).closest('.box');
         //$parent_box.find('.bottom').slideUp();
         //  $(".details-info").hide();
         $parent_box.find('.bottom').slideToggle(1000, 'swing');
         //$parent_box.find('.bottom').fadeIn(1000, 'swing');
         // $(".details-info").show();
     });
     
     $('.middle-top').on('click', function() {
     
         $parent_box = $(this).closest('.middle-box');
         $parent_box.siblings().find('.middle-bottom').slideUp();
         //  $(".details-info").hide();
         $parent_box.find('.middle-bottom').slideToggle(1000, 'swing');
         //$parent_box.find('.bottom').fadeIn(1000, 'swing');
         // $(".details-info").show();
     });
	 $(".hideAll").on("click", function(){
		var id=$(this).attr("id");
		$(".hideRow").hide();
		$(".hideRow"+id).show();
	});

</script>
@endsection