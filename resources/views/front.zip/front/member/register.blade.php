@extends('front.layout.main')
@section('middle_content')
<script type="text/javascript" language="javascript" src="{{url('/')}}/js/front/parsley.min.js"></script>
<!-- <link href="{{url('/')}}/css/front/parlsey.css" rel="stylesheet" type="text/css" /> -->
<div class="signup-banner">
   <div class="pattern-signup">
      <div class="container">
         <div class="row">
            <div class="col-lg-12">
               <div class="signup-heading">New Member? Register here!</div>
            </div>
         </div>
      </div>
   </div>
</div>
<!--end-->
<!--middle section-->
@include('front.layout._operation_status')
<div class="middle-area">
   <div class="container">
      <div class="row">
         <div class="col-sm-12 col-md-8 col-lg-6">
            <div class="form-wrapper">
               <h3>Have you attended lots of Interviews? Would you like to share interview questions &amp answers &amp; monetize your experience?</h3>
               <form action="{{url('/member/store')}}" id="frm_store_member" method="POST" data-parsley-validate>
               {{ csrf_field() }}
               @include('front.layout._operation_status')
               <!--process box-->
               <div class="process-bx">
                  <div class="center-row">
                     <div class="step_process border-line">
                        <div class="active-step step_bor">
                           <div class="active_step normal_step">1</div>
                        </div>
                        <div class="plan-detail left1">
                           <div class="active step_title">Personal</div>
                        </div>
                     </div>
                     <div class="bg_i">&nbsp;</div>
                     <div class="step_process border-line">
                        <div class="step_bor">
                           <div class="normal_step">2</div>
                        </div>
                        <div class="plan-detail left2">
                           <div class="step_title">Employment</div>
                        </div>
                     </div>
                     <div class="bg_i">&nbsp; </div>
                     <div class="step_process">
                        <div class="step_bor">
                           <div class="normal_step">3</div>
                        </div>
                        <div class="plan-detail left3">
                           <div class="step_title">Education</div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--end-->
               <div class="row">
                  <div class="col-sm-6 col-md-6 col-lg-6 first-name">
                     <div class="form-group">
                        <label>First Name <span class="star">*</span></label>

                        <input type="text" name="first_name" value="{{old('first_name')}}" class="input-box-signup" data-parsley-pattern="^[a-zA-Z]+$"
                        data-parsley-pattern-message="First name should be only characters" placeholder="Enter Your First Name" required="" data-parsley-errors-container="#err_first_name" data-parsley-required-message="This field is required" />
                           <div id="err_first_name" class="error"></div>
                            <div class="error">{{ $errors->first('first_name') }}</div>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-6 col-lg-6 last-name">
                     <div class="form-group">
                        <label>Last Name <span class="star">*</span></label>
                        <input type="text" name="last_name"  value="{{old('last_name')}}" class="input-box-signup" placeholder="Enter Your Last Name" required="" 
                        data-parsley-pattern="^[a-zA-Z]+$"
                        data-parsley-pattern-message="Last name should be only characters"
                           data-parsley-errors-container="#err_last_name" data-parsley-required-message="This field is required" />
                           <div id="err_last_name" class="error"></div>
                             <div class="error">{{ $errors->first('last_name') }}</div>
                     </div>
                  </div>
               </div>

               <div class="form-group">
                  <label>Email Address <span class="star">*</span></label>
                  <input type="text" name="email"
                        data-rule-email="true" class="input-box-signup" id="email_verifi" value="{{old('email')}}" placeholder="Enter Your Email Address" onchange="javascript: return email_verification();" required="" data-parsley-type="email" data-parsley-errors-container="#err_email" data-parsley-required-message="This field is required" />
                           <div id="err_email" class="error" style="margin-bottom:6px;"></div>
                           <span id="verify_err_email" class="error" style="margin-top:6px;"></span>
                            <div class="error">{{ $errors->first('email') }}</div>
               </div>

               <div class="form-group">
                  <label>Password <span class="star">*</span></label>
                  <input type="password" id="password" name="password" class="input-box-signup" placeholder="Enter Your Password"  required="" data-parsley-pattern="((?=.*\d)(?=.*[!@#$%]).{6,})" data-parsley-errors-container="#err_password" data-parsley-required-message="This field is required" data-parsley-pattern-message="Password must be 6 characters in length and contain atleast one special character and number."/>
                           <div id="err_password" class="error"></div>
                           <div class="error">{{ $errors->first('password') }}</div>
               </div>
               <div class="form-group">
                  <label>Confirm Password <span class="star">*</span></label>
                  <input type="password" name="con_password"
                         data-rule-equalto='#password' class="input-box-signup" placeholder="Enter Your Confirm Password"  required="" data-parsley-equalto="#password" data-parsley-errors-container="#err_con_password" data-parsley-required-message="This field is required" data-parsley-equalto-message="Password and confirm password must be the same." />
                           <div id="err_con_password" class="error"></div>
                            <div class="error">{{ $errors->first('con_password') }}</div>
               </div>
         
    <div id="form-group">
             <div class="col-sm-4" style="padding:0px"> 
             <div class="form-group">
                        <label>Country<span class="star">*</span></label>
                        <div class="select-number"  style="width: 95.8%;">
                       

                                <input type="text"  class="input-box-signup keypressit" id="country_id" name="country_id" data-parsley-required="true"    data-parsley-errors-container="#err_country_id" data-parsley-required-message="This field is required"   autocomplete="off" />

<div class="auto-search-box" >
  
<div class="auto-search-boxul"></div>

</div>

                            <div id="err_country_id" class="error"></div>
                        </div>
                        </div>
                        </div>
            <div class="col-sm-4" style="padding:0px">
                        <div class="form-group">
                           <label>
                              State<span class="star">*</span> 
                           </label>
               <div class="select-number"  style="width: 95.8%;">
                          
                            <input type="text" name="state_id" class="input-box-signup keystate" data-parsley-required="true"    data-parsley-errors-container="#err_state_id" data-parsley-required-message="This field is required"  />


                            <div class="auto-search-box-state" ></div>






                            <input type="hidden" class="countrycodes" name="countrycodes">
               </div>
               <div id="err_state_id" class="error"></div>
                           <!--  <div class="error">{{ $errors->first('other_state') }}</div> -->
                        </div>
                        </div>
            <div class="col-sm-4" style="padding:0px">
                        <div class="form-group">
                           <label>
                              City
                           </label>
               <div class="select-number"  style="width: 95.8%;">
                           

     <input type="text"  class="input-box-signup keycity" name="city_id"    data-parsley-errors-container="#err_city_id"   />

      <div class="auto-search-box-city" ></div>




 <input type="hidden" class="satecodeset" name="satecodeset">

               </div>
               <div id="err_city_id" class="error"></div>
                        </div>
                        </div>
                        
         </div>
               <div class="form-group" style="clear:both">
                  <label>Mobile Number <span class="star">*</span></label>
                  <div class="row">
                     <div class="col-xs-3 col-sm-3 col-md-2 mumber-box-left">
                      <input type="text" name="mobile_code" id="mobile_code"
                               class="input-box-signup" value="+91" data-parsley-pattern="\+[0-9]{1,3}"
                        data-parsley-pattern-message="Enter Valid Country Code" required="" data-parsley-errors-container="#err_mobile_code" data-parsley-required-message="Field required" readonly />
                               <div id="err_mobile_code" class="error"></div>
                            <div class="error">{{ $errors->first('mobile_code') }}</div>
                     </div>
                     <div class="col-xs-9 col-sm-9 col-md-10 mumber-box-right">
                        <input type="text" name="mobile_no"
                               data-rule-digits="true" class="input-box-signup" value="{{old('mobile_no')}}" placeholder="Enter Your Mobile Number" required="" data-parsley-type="integer" data-parsley-errors-container="#err_mobile_no" data-parsley-required-message="This field is required" data-parsley-minlength="7" data-parsley-maxlength="16"/>
                           <div id="err_mobile_no" class="error"></div>
                            <div class="error">{{ $errors->first('mobile_no') }}</div>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <label>Birth Date <span class="star">*</span></label>
                  <div class="row">
                     <div class="col-sm-4">
                        <div class="select-number">
                           <select name="date" required="" data-parsley-errors-container="#err_birth_date" data-parsley-required-message="This field is required">
                              <option value="">Date</option>
                      @for($i=1;$i<=31;$i++) 
                      <option value="{{str_pad($i, 2, '0', STR_PAD_LEFT) }}"> {{str_pad($i, 2, '0', STR_PAD_LEFT)}}</option>
                      @endfor
                           </select>
                           <div id="err_birth_date" class="error"></div>
                           <div class="error">{{ $errors->first('date') }}</div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="select-number">
                           <select name="month" required="" data-parsley-errors-container="#err_birth_month" data-parsley-required-message="This field is required">
                        <option value="">Month</option>
                        <option value="01">Jan</option>
                        <option value="02">Feb</option>
                        <option value="03">Mar</option>
                        <option value="04">Apr</option>
                        <option value="05">May</option>
                        <option value="06">Jun</option>
                        <option value="07">Jul</option>
                        <option value="08">Aug</option>
                        <option value="09">Sep</option>
                        <option value="10">Oct</option>
                        <option value="11">Nov</option>
                        <option value="12">Dec</option>
                              </select>
                               <div id="err_birth_month" class="error"></div>
                              <div class="error">{{ $errors->first('month') }}</div>
                        </div>
                     </div>
                    
                     <div class="col-sm-4">
                     <?php $current_year = date('Y');
                           $year = $current_year-23;
                      ?>
                      
                        <div class="select-number">
                           <select name="year" required="" data-parsley-errors-container="#err_birth_year" data-parsley-required-message="This field is required">
                                 <option value="">Year</option>
                                  @for($i=$year;$i>=1950;$i--) 
                                  <option value="{{$i}}"> {{$i}}</option>
                                  @endfor
                              </select>
                                <div id="err_birth_year" class="error"></div>
                                  <div class="error">{{ $errors->first('year') }}</div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--inline Radio button-->
               <div class="form-group">
                     <div class="row">
                        <div class="col-sm-12 col-md-3 col-lg-2">
                           <div class="form-lable">Gender: </div>
                        </div>
                        <div class="col-sm-12 col-md-9 col-lg-10">
                           <div class="radio-btns">
                              <div class="radio-btn">
                                 <input id="genderm" required="" name="gender" value="M" type="radio" required="" data-parsley-errors-container="#err_gender" data-parsley-required-message="This field is required">
                                 <label for="genderm">Male</label>
                                 <div class="check left-min"></div>
                              </div>
                              <div class="radio-btn">
                                 <input  id="genderf" value="F" name="gender" type="radio">
                                 <label for="genderf">Female</label>
                                 <div class="check left-min">
                                    <div class="inside"></div>
                                 </div>
                              </div>
                           </div>
                            <div id="err_gender" class="error"></div>
                            <div class="error">{{ $errors->first('gender') }}</div>
                        </div>
                        <div class="clearfix"></div>
                     </div>
                  </div>
                  
               <!--end-->
               <div class="text-right m-top"><button type="submit" class="submit-btn ctn">Continue</button> </div>
               </form>
            </div>
         </div>
         <div class="col-sm-12 col-md-4 col-lg-6">
            <!--right section-->
            <div class="signup-personal-RightSection row">
               <div class="line-empty">&nbsp;</div>
               <div class="signup-personal-img pull-right text-center col-sm-12 col-md-12 col-lg-6">
                  <img src="{{url('/')}}/images/signup-Personal-img1.png" alt="Interviewxp" class="img-responsive img-d hidden-xs hidden-sm hidden-md">
                  <img src="{{url('/')}}/images/doller.png" alt="Interviewxp" class="img-responsive visible-xs visible-sm visible-md">
                  <h5>You Could earn an extra income of 5,000/- to 1,00,000/- Plus every month</h5>
               </div>
               <div class="clr"></div>
               <div class="signup-personal-img pull-left text-center col-sm-12 col-md-12 col-lg-6">
                  <img src="{{url('/')}}/images/signup-Personal-img2.png" alt="Interviewxp" class="img-responsive img-d-r hidden-xs hidden-sm hidden-md">
                  <img src="{{url('/')}}/images/person.png" alt="Interviewxp" class="img-responsive visible-xs visible-sm visible-md">
                  <h5>It might be useful to repay your loans, or dream trip to foreign countries</h5>
               </div>
               <div class="clr"></div>
               <div class="signup-personal-img pull-right text-center col-sm-12 col-md-12 col-lg-6">
                  <img src="{{url('/')}}/images/signup-Personal-img3.png" alt="Interviewxp" class="img-responsive img-d hidden-xs hidden-sm hidden-md">
                  <img src="{{url('/')}}/images/signup-img3.png" class="img-responsive visible-xs visible-sm visible-md">
                  <h5>Share, contribute your real time work experience and interview Q &amp; A</h5>
               </div>
               <div class="clr"></div>
               <div class="signup-personal-img pull-left text-center col-sm-12 col-md-12 col-lg-6">
                  <img src="{{url('/')}}/images/signup-Personal-img4.png" alt="Interviewxp" class="img-responsive img-d-r hidden-xs hidden-sm hidden-md">
                  <img src="{{url('/')}}/images/rocket.png" alt="Interviewxp" class="img-responsive visible-xs visible-sm visible-md">
                  <h5>Spare your time, 8 hours a month and make more money at interviewxp</h5>
               </div>
            </div>
            <!--end-->
                           <!--contact details box-->
                 
                  <div class="contact-details pull-right">
                     <div class="inner-details">
                        <h4>Customer Support</h4>
                        <div class="inner-details2">
                           <div class="contact-icon"><img src="{{url('/')}}/images/landline.png"></div>
                           <div class="contact-details2">
                              <h5>Landline:</h5>
                              <h6>040-646487</h6>
                           </div>
                        </div>
                        <div class="inner-details2">
                           <div class="contact-icon"><img src="{{url('/')}}/images/mobile.png"></div>
                           <div class="contact-details2">
                              <h5>Mobile no.:</h5>
                              <!-- <h6>9000000009</h6> -->
                              <h6>{{$arr_user_details[0]['mobile_no']}}</h6>
                           </div>
                        </div>
                        <div class="inner-details2">
                           <div class="contact-icon"><img src="{{url('/')}}/images/email.png"></div>
                           <div class="contact-details2">
                              <h5>Email:</h5>
                             <!--  <h6 class="email">support@interviewxp.com</h6> -->
                              <h6 class="email">{{$arr_user_email[0]['general_email']}}</h6>
                           </div>
                        </div>
                     </div>
                  </div>
                  
                  <!--end-->
            
         </div>
      </div>
   </div>
</div>

<script type="text/javascript">

$(document).ready(function() {   




$('input').attr('autocomplete', 'off');

$(document).on('keyup', '.keypressit', function() {

var kyvalue=$(this).val(); var kyvalueres=kyvalue.replace(' ', '-'); var kyvaluelenght=kyvalueres.length; 
if(kyvaluelenght>=2)
{ $('.auto-search-box').css('display','block');
 $.ajax({
            url: "{{url('/get_country_codename')}}",
            type: "get",
            data: {country_id: kyvalueres},
      dataType:'json',
            success: function (data) {
             
                $('.auto-search-boxul').html(data);
            }
        }); } 
else {
      $('.auto-search-box').css('display','none'); 

} });




$(document).on('click', '.searchp', function() {

$mainvalue=$(this).attr('id');

var kyvalueres=$mainvalue.split('-');;


$('.keypressit').val(kyvalueres[1]);
$mobile_code='+'+kyvalueres[2];
$('#mobile_code').val($mobile_code);
$('.countrycodes').val(kyvalueres[0]);


 $('.auto-search-box').css('display','none'); 
});




$(document).on('keyup', '.keystate', function() {

var kyvalue=$(this).val(); var kyvalueres=kyvalue.replace(' ', '-'); var kyvaluelenght=kyvalueres.length; 
var country_id=$('.countrycodes').val();
if(kyvaluelenght>=2)
{ $('.auto-search-box-state').css('display','block');
 $.ajax({
            url: "{{url('/get_state_codename')}}",
            type: "get",
            data: {country_id: country_id, state_id: kyvalueres},
      dataType:'json',
            success: function (data) {
             
                $('.auto-search-box-state').html(data);
            }
        }); } 
else {
      $('.auto-search-box-state').css('display','none'); 

} });




$(document).on('click', '.searchpstate', function() {

$mainvalue=$(this).attr('id');

var kyvalueres=$mainvalue.split('-');;

$('.satecodeset').val(kyvalueres[0]);



$('.keystate').val(kyvalueres[1]);



 $('.auto-search-box-state').css('display','none'); 
});









$(document).on('keyup', '.keycity', function() {

var kyvalue=$(this).val(); var kyvalueres=kyvalue.replace(' ', '-'); var kyvaluelenght=kyvalueres.length; 
var country_id=$('.satecodeset').val();

if(kyvaluelenght>=2)
{ $('.auto-search-box-city').css('display','block');
 $.ajax({
            url: "{{url('/get_city_codename')}}",
            type: "get",
            data: {country_id: country_id, state_id: kyvalueres},
      dataType:'json',
            success: function (data) {
             
                $('.auto-search-box-city').html(data);
            }
        }); } 
else {
      $('.auto-search-box-city').css('display','none'); 

} });


$(document).on('click', '.searchpcity', function() {

$mainvalue=$(this).attr('id');

var kyvalueres=$mainvalue.split('-');;

$('.satecodeset').val(kyvalueres[0]);



$('.keycity').val(kyvalueres[1]);



 $('.auto-search-box-city').css('display','none'); 
});










    $('#country_id').on('change', function () {
        var country = this.value;
        var state = '';
        getStates(country, state);
    getCountryPhoneCode(country);
        getCities(0,'');
    });
    $('#state_id').on('change', function () {
        var state = this.value;
        var city = '';
    getCities(state, city);
    });
   

});

function getCountryPhoneCode(country_id){
     $.ajax({
            url: "{{url('/get_country_phone_code')}}",
            type: "get",
            data: {country_id: country_id},
      dataType:'json',
            success: function (data) {
                $('#mobile_code').val(data);
            }
        });
}

function getStates(country_id, state_id=''){
     $.ajax({
            url: "{{url('/get_states')}}",
            type: "get",
            data: {country_id: country_id, state_id: state_id},
      dataType:'json',
            success: function (data) {
                $('#state_id').html(data);
            }
        });
}

function getCities(state_id, city_id=''){
    $.ajax({
        url: "{{url('/get_cities')}}",
        type: "get",
        data: {state_id: state_id, city_id: city_id},
    dataType:'json',
        success: function (data) {
            $('#city_id').html(data);
        }
    });
}

</script>
<script type="text/javascript">
   function email_verification()
   {
      var link = "{{ url('/member/email_verification') }}";
        
         
         var email = $('#email_verifi').val();
         var _token = $("input[name=_token]").val();

         var arr_data = {
                          email:email,
                          _token :_token,   
                        }
        jQuery.ajax({
                        url:link,
                        type:'post',
                        dataType:'json',
                        data:arr_data,
                        beforeSend:function()
                        {
                          $('#verify_err_email').html('');
                        },
                        success:function(response)
                        {
                           if(response.status=="ERROR")
                            {
                              $('#verify_err_email').html('EmailId already exists.');
                              $("#verify_err_email").show().fadeOut(2000);
                              $('#email_verifi').val('');
                            }
                            if(response.status=="SUCCESS")
                            {
                              $('#verify_err_email').html('');  
                            }
                        } 
                       });     
  }   
</script>
@endsection

