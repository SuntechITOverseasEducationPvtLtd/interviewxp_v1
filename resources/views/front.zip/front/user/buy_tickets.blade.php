@extends('front.layout.main') 
@section('middle_content')
<div id="header-home" class="home-header"></div>
<div class="banner-change-pw">
    <div class="pattern-change-pw">
        
    </div>
</div>
<!-- tickets -->
<div class="middle-area min-height">
    <div class="container">
		
	</div>
</div>
@endsection