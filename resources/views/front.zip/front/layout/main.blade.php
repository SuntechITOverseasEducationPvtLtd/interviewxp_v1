@include('front.layout._header')

	@yield('middle_content')

@include('front.layout._footer')
