@extends('front.layout.main')
@section('middle_content')     
<style>
.revenue .table-search-pati.section1-tab tr td {
    padding: 8px 9px;
    text-align: left;
}
.table-search-pati table tr td {    font-size: 14px;}
</style>
      <div class="banner-member">
         <div class="pattern-member">
         </div>
      </div>
      <div class="container-fluid fix-left-bar max-height">
         <div class="row">
            @include('front.member.member_sidebar')
            <div class="col-sm-8 col-md-9 col-lg-10 middle-content">
               <h2 class="my-profile pages">{{$module_title}}</h2>
               <div class="row">
                  <div class="col-sm-12 col-md-12 col-lg-12">
                     <div class="middle part green-table">
                        <div class="outer-box revenue">
                           <div class="icon-wrapper" style="display:none"> 
                              <a style="visibility:hidden" href="#" class="delete-i-top"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                              <!--<a href="{{url('/member/revenue_reports')}}" class="refresh-i"><i class="fa fa-refresh" aria-hidden="true"></i></a>-->
                           </div>
                           <div class="table-search-pati section1-tab history-page">
                              <div class="table-responsive" style="border:0">

                                <input type="hidden" name="multi_action" value="" />

                                      <table class="datatable table table-striped table-bordered table table-advance" >
                                  <thead>
                                    <tr class="t-head">
                                        
                                         <td>S.No <i class="fa fa-fw fa-sort"></i></td>
                                     <!--  <th>Transaction Id</th> -->
                                         <td>Month Wise Sales <i class="fa fa-fw fa-sort"></i></td>
                                         <td>Total Earnings <i class="fa fa-fw fa-sort"></i></td>
                                         <td>Tax <i class="fa fa-fw fa-sort"></i></td>
                                         <td>Net Pay <i class="fa fa-fw fa-sort"></i></td>
                                         <td>Payout Date <i class="fa fa-fw fa-sort"></i></td>
                                         <td>Payment Status <i class="fa fa-fw fa-sort"></i></td>
                                         
                                    </tr>
                                  </thead>
                                  <tbody>
                                    @if(isset($entries) && sizeof($entries)>0)
                                      <?php $i=0; ?>
                                      @foreach($entries  as $key => $data)
                                      <?php $i=$i+1;  if($i%2==0) { $classg="asgreen";} else {  $classg="aswhite"; } ?>
                                      <tr class="{{$classg}}">
                                       
                                         <td style="width:80px"> 
                                             {{$i}}
                                         </td>
                                         <!-- <td > IE0000{{ $data['id'] or 'NA' }} </td> -->

                                         <td> <a href="{{url('/member/revenue/'.base64_encode($data[0]).'/'.base64_encode($data[1]))}}">{{$data[2]}} </a></td>
                                         <td style="width:140px"> 
                                             {{$data['member_amount']}}
                                         </td>
                                         <td style="width:80px"> 
                                             {{$data['member_tax_amount']}}
                                         </td>
                                         <td style="width:100px"> 
                                             {{$data['after_tax_amount']}}
                                         </td>
                                        <td style="width:130px"> 
                                             {{$data['payout_date']}}
                                         </td>
                                      <td style="width:150px"> 
                                            @if($data['member_payment_status']=="Dont Pay" || $data['member_payment_status']=="Pay")
                                                Pending
                                             @elseif($data['member_payment_status']=="Paid")
                                                Paid   
                                             @endif
                                         </td>
                                         
                                         
                                      </tr>
                                      @endforeach

                                    @endif
                                  </tbody>
                                </table>
                                
                              </div>
                           </div>
                                       
                        </div>
                        

                     </div>
                  </div>
                 
               </div>
            </div>
         </div>
      </div>
      </div>
      
      	<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.9.4/jquery.dataTables.min.js"></script>
	<script src="http://cloudforcehub.com/interviewxp/js/datatables.js"></script>
		<script type="text/javascript">
		$(document).ready(function() {
			$('.datatable').dataTable({
				"sPaginationType": "bs_full"
			});	
			$('.datatable').each(function(){
				var datatable = $(this);
				// SEARCH - Add the placeholder for Search and Turn this into in-line form control
				var search_input = datatable.closest('.dataTables_wrapper').find('div[id$=_filter] input');
				search_input.attr('placeholder', 'Search');
				search_input.addClass('form-control input-sm');
				// LENGTH - Inline-Form control
				var length_sel = datatable.closest('.dataTables_wrapper').find('div[id$=_length] select');
				length_sel.addClass('form-control input-sm');
			});
		});
		</script>
@endsection       

