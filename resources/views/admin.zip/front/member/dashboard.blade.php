@extends('front.layout.main')
@section('middle_content')
<div class="banner-member">
         <div class="pattern-member">  
         </div>
      </div>
       <div class="middle-area min-height">
           <div class="container">
               <div class="row">
                   <div class="col-md-6 form-wrapper">
                       <div class="form-group">
                           <label><h1>Coming Soon</h1></label>
                           
                           <!--div class="error">Password is not Valid</div-->
                       </div>
                       
                   </div>
               </div>
           </div>
           
       </div>
    
        

@endsection