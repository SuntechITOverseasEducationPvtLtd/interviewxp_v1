<link href="{{url('css/front/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
      <!-- main CSS -->
<link href="{{url('css/front/Interviewxp.css')}}" rel="stylesheet" type="text/css" />
  <link href="{{url('css/front/font-awesome.min.css')}}" rel="stylesheet" type="text/css" />
@yield('middle_content')

