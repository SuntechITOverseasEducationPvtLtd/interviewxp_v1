<?php $video=$_GET['video']; ?>
	
	 <iframe src="http://interviewxp.com/videoplayer/player_company.php?video=<?=$video;?>" style="width:100%; height:590px; border:none"></iframe>	
	 