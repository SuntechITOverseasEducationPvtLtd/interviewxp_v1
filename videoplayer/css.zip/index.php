<?php $video=$_GET['video']; ?>
	
	 <iframe src="http://cloudforcehub.com/interviewxp/videoplayer/player.php?video=<?=$video;?>" style="width:100%; height:590px; border:none"></iframe>	
	 